package org.example;

public class GroupedMetricSummary {
}
